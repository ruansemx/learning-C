#include <stdio.h>
#include <cs50.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>

int main (int argc, string argv[])
{
//configurando o argumento
    if (argc != 2)
    {
        printf("Usage: ./cesar key.\n");
    }

//configurando a chave
    string key = argv[1];

//verificando se a chave é composta apenas por dígitos
    for (int i = 0; i < strlen(argv[1]); i++)
    {
        if (!isdigit(argv[1][i]))
        {
            printf("Usage: ./cesar key.\n");
            return 1;
        }
    }
//obtendo o texto base
    string texto = get_string ("Plaintext: ");

    int k = atoi(key);
    printf("Ciphertext: ");

    for (int j = 0; j < strlen(texto); j++)
    if (isupper(texto[j]))
    {
        printf("%c", (((texto[j] - 65) + k) %26) + 65);
    }
    else if (islower(texto[j]))
    {
        printf("%c", (((texto[j] - 97) + k) %26) + 97);
    }
    else
    {
        printf("%c", texto[j]);
    }
    printf("\n");
}