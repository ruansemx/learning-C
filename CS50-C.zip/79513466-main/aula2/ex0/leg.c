#include <stdio.h>
#include <string.h>
#include <cs50.h>
#include <ctype.h>
#include <math.h>

//índice = 0,0588 * L - 0,296 * S - 15,8
//L = letras / palavras * 100
//S = sentenças / palavras * 100
int main(void)
{
//declarando variáveis
    int tam, l = 0, i, p = 1, j, s = 0, k;
//obtendo o input do texto
    string texto = get_string ("Input a text here:\n");
//definindo a variável de strlen
    tam = strlen(texto);
//calculando as letras
    for(i = 0; i < tam; i++)
    {
        if(isalpha(texto[i]) != 0)
        l++;
    }
    printf("Your text has %i letters\n", l);
//calculando as palavras
    for(j = 0; j < tam; j++)
    {
        if(texto[j] == ' ')
        p++;
    }
     printf("Your text has %i words\n", p);
//calculando as sentenças
        for(k = 0; k < tam; k++)
    {
        if (texto[k] == '.' || texto[k] == '!' || texto[k] == '?')
        s++;
    }
     printf("Your text has %i sentences\n", s);
//calculando o nível do texto
    float index  = ((0.0588 * l / p * 100) - (0.296 * s / p * 100) - 15.8);
    int grade = round(index);

    if (grade < 1)
    {
        printf ("Before grade 1.\n");
    }

    else if (grade > 16)
    {
        printf("Grade 16+.\n");
    }
    else
    {
        printf("The text grade is %d.\n", grade);
    }
}