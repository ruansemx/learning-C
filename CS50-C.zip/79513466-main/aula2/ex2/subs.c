#include <stdio.h>
#include <cs50.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>

int main (int argc, string argv[])
{
//configurando o argumento
    if (argc != 2)
    {
        printf("Usage: ./subs key.\n");
    }

//configurando a chave
    string key = argv[1];

//verificando se a chave é composta apenas por letras
    for (int i = 0; i < strlen(argv[1]); i++)
    {
        if (!isalpha(argv[1][i]))
        {
            printf("Usage: ./subs key.\n");
            return 1;
        }
    }
//verificando se a chave tem 26 letras
    if (strlen(key) != 26)
    {
        printf("The key must contain 26 characters.\n");
        return 1;
    }
//excluindo duplicatas
    for (int i = 0; i < strlen(key); i++)
    {
        for (int j = i + 1; j < strlen(key); j++)
        {
            if (toupper(key[i]) == toupper(key[j]))
            {
                printf("Usage: ./subs Key.");
                return 1;
            }
        }
    }
//obtendo o texto base
    string texto = get_string ("Plaintext: ");

    printf("Ciphertext: ");
    for (int i = 0; i < strlen(key); i++)
    {
        if(islower(key[i]))
        {
            key[i] = key[i] - 32;
        }
    }

    for (int j = 0; j < strlen(texto); j++)
    if (isupper(texto[j]))
    {
        int letra = texto[j] - 65;
        printf("%c", (key[letra]));
    }
    else if (islower(texto[j]))
    {
        int letra = texto[j] - 97;
        printf("%c", (key[letra]));
    }
    else
    {
        printf("%c", texto[j]);
    }
    printf("\n");
}