#include<stdio.h>
#include<cs50.h>

int main(void)
{
    long card;
    int ck0, ck1, ck2, ck3, ck4, ck5, ck6, ck7, ck8, ck9, ck10, ck11, ck12, ck13, ck14, ck15, soma1, soma2, soma3;
    do
    {
    card = get_long ("Digite o número do seu cartão: ");
    }
    while (card <= 0);

    ck0 = card % 10;
    ck1 = card % 100 / 10 * 2;
    ck2 = card % 1000 / 100;
    ck3 = card % 10000 / 1000 * 2;
    ck4 = card % 100000 / 10000;
    ck5 = card % 1000000 / 100000 * 2;
    ck6 = card % 10000000 / 1000000;
    ck7 = card % 100000000 / 10000000 * 2;
    ck8 = card % 1000000000 / 100000000;
    ck9 = card % 10000000000 / 1000000000 * 2;
    ck10 = card % 100000000000 / 10000000000;
    ck11 = card % 1000000000000 / 100000000000 * 2;
    ck12 = card % 10000000000000 / 1000000000000;
    ck13 = card % 100000000000000 / 10000000000000 * 2;
    ck14 = card % 1000000000000000 / 100000000000000;
    ck15 = card % 10000000000000000 / 1000000000000000 * 2;

    ck1 = (ck1 % 100 / 10) + (ck1 % 10);
    ck3 = (ck3 % 100 / 10) + (ck3 % 10);
    ck5 = (ck5 % 100 / 10) + (ck5 % 10);
    ck7 = (ck7 % 100 / 10)+ (ck7 % 10);
    ck9 = (ck9 % 100 / 10) + (ck9 % 10);
    ck11 = (ck11 % 100 / 10) + (ck11 % 10);
    ck13 = (ck13 % 100 / 10) + (ck13 % 10);
    ck15 = (ck15 % 100 / 10) + (ck15 % 10);

    soma1 = ck0+ck2+ck4+ck6+ck8+ck10+ck12+ck14;
    soma2 = ck1+ck3+ck5+ck7+ck9+ck11+ck13+ck15;
    soma3 = soma1 + soma2;

    if ((soma3 % 10) != 0)
    {
        printf("Cartão inválido\n");
        return 0;
    }
    int tam = 0;
    long visa = card;
    long amex = card;
    long master = card;

    while (card > 0)
    {
        card = card/10;
        tam++;
    }

    while (visa > 10)
    {
        visa = visa/10;
    }

    if (visa == 4 && (tam == 13 || tam == 16))
    {
        printf("Seu cartão é Visa.\n");
        return 0;
    }

    while (amex > 10000000000000)
    {
        amex = amex/10000000000000;
    }
    if (tam == 15 && (amex == 34 || amex == 37))
    {
        printf("Seu cartão é Amex.\n");
        return 0;
    }

    while (master > 100000000000000)
    {
        master = master/100000000000000;
    }
    if (tam == 16 && (master == 51 || master == 52 || master == 53 || master == 54 || master == 55))
    {
        printf("Seu cartão é MasterCard");
        return 0;
    }
}