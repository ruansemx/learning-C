#include<stdio.h>
#include<cs50.h>

int main(void)
{
    int inic, fin, anos;
    do
    {
        inic = get_int("Qual a população inicial? ");
    }
    while (inic < 9);

    do
    {
        fin = get_int("Qual a população final? ");
    }
    while (fin <= inic);

    anos = 0;

    while (inic < fin)
    {
        inic = inic + (inic / 3) - (inic / 4);
        anos++;
    }

    printf("%i\n", anos);
}