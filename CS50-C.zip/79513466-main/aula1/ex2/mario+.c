#include<cs50.h>
#include<stdio.h>

int main(void)
{
    int alt, nl, coluna, eps, esp;
    do
    {
        alt = get_int("Qual a altura desejada? ");
    }
    while (1 > alt || alt > 8);

    {
    for (nl = 0; nl < alt; nl++)
     {
        for (eps = 0; eps < alt - nl - 1; eps++)
         {
             printf(" ");
         }
        for (coluna = 0; coluna <= nl; coluna++)
        {
            printf("#");
        }
        for (coluna = 0; coluna < 1; coluna++)
        {
            printf("   ");
        }
        for (coluna = 0; coluna <= nl; coluna++)
        {
            printf("#");
        }
            printf("\n");
     }
    }
}