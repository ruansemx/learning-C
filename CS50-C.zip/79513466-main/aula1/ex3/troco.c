#include<stdio.h>
#include<cs50.h>
#include<math.h>

// obter input do valor da compra, do valor pago, e dar o output do troco mais eficiente
int main(void)
{
    float devido, pago, diferença;
    int uc = 0;
    int cc = 0;
    int dc = 0;
    int vcc = 0;
    int cqc = 0;
    int ur = 0;
    int dr = 0;
    int cr = 0;
    int dzr = 0;
    int vr = 0;
    int cqr = 0;
    int cmr = 0;
    int dcr = 0;
    do
    {
        devido = get_float("Qual o valor devido? ");
    }
    while (devido < 0.01);

    do
    {
        pago = get_float("Qual o valor pago? ");
    }
    while (pago < devido);

    diferença = pago - devido;

    int troco;
    troco = round(diferença * 100);

    while (troco > 20000 || troco == 20000)
    {
        troco = troco - 20000;

        dcr++;
    }

    while (troco > 10000 || troco == 10000)
    {
        troco = troco - 10000;

        cmr++;
    }

    while (troco > 5000 || troco == 5000)
    {
        troco = troco - 5000;

        cqr++;
    }

    while (troco > 2000 || troco == 2000)
    {
        troco = troco - 2000;

        vr++;
    }

    while (troco > 1000 || troco == 1000)
    {
        troco = troco - 1000;

        dzr++;
    }

    while (troco > 500 || troco == 500)
    {
        troco = troco - 500;

        cr++;
    }

    while (troco > 200 || troco == 200)
    {
        troco = troco - 200;

        dr++;
    }

    while (troco > 100 || troco == 100)
    {
        troco = troco - 100;

        ur++;
    }

    while (troco > 50 || troco == 50)
    {
        troco = troco - 50;

        cqc++;
    }

    while (troco > 25 || troco == 25)
    {
        troco = troco - 25;

        vcc++;
    }

    while (troco > 10 || troco == 10)
    {
        troco = troco - 10;

        dc++;
    }

    while (troco > 5 || troco == 5)
    {
        troco = troco - 5;

        cc++;
    }

    while (troco > 1 || troco == 1)
    {
        troco = troco - 1;

        uc++;
    }
    printf("O seu troco é igual a R$ %.2f\n", diferença);
    printf("Sendo:\n");
    if (dcr > 0)
    {
        printf("%i cédulas de R$ 200,00\n", dcr);
    }
    if (cmr > 0)
    {
        printf("%i cédulas de R$ 100,00\n", cmr);
    }
    if (cqr > 0)
    {
        printf("%i cédulas de R$ 50,00\n", cqr);
    }
    if (vr > 0)
    {
        printf("%i cédulas de R$ 20,00\n", vr);
    }
    if (dzr > 0)
    {
        printf("%i cédulas de R$ 10,00\n", dzr);
    }
    if (cr > 0)
    {
        printf("%i cédulas de R$ 5,00\n", cr);
    }
    if (dr > 0)
    {
        printf("%i cédulas de R$ 2,00\n", dr);
    }
    if (ur > 0)
    {
        printf("%i moedas de R$ 1,00\n", ur);
    }
    if (cqc > 0)
    {
        printf("%i moedas de R$ 0,50\n", cqc);
    }
    if (vcc > 0)
    {
        printf("%i moedas de R$ 0,25\n", vcc);
    }
    if (dc > 0)
    {
        printf("%i moedas de R$ 0,10\n", dc);
    }
    if (cc > 0)
    {
        printf("%i moedas de R$ 0,05\n", cc);
    }
    if (uc > 0)
    {
        printf("%i moedas de R$ 0,01\n", uc);
    }

    printf("Totalizando %i cédulas e %i moedas\n", dcr + cmr + cqr + vr + dzr + cr + dr + ur, cqc + vcc + dc + cc + uc);
}